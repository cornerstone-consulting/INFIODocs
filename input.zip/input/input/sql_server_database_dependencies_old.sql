/*************************************************************
Developer: Scott Peters
Date: 04/03/2024

This script performs an analysis of the database dependencies as
established in the `sys.sql_expression_dependency' table.

See the Microsoft documentation below.
https://learn.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-sql-expression-dependencies-transact-sql?view=sql-server-ver16



---------------------------------------------------------------
This script consists of three parts.
1.  Determine dependencies from `sys.sql_expression_dependency`.
2.  Determine rules that need to be applied.
3.  Determine the depth of each object.

---------------------------------------------------------------

Notes:
A dependency between two entities is created when one entity, 
called the referenced entity, appears by name in a persisted 
SQL expression of another entity called the referencing entity.

For example, consider a view that references a table.  
The view will be the referencing entity and the table will be the 
referenced entity.

************************************************************/

SET NOCOUNT ON;


DROP TABLE IF EXISTS #SQL_Statement;          --  Contains the dynamic sql to execute
DROP TABLE IF EXISTS ##DB_Dependencies;       --  Final table that is populated
DROP TABLE IF EXISTS ##ObjectsWithNoAnchor

--  This table is created in another script, 
--  ensure it gets dropped to ensure it is accurate.
DROP TABLE IF EXISTS ##DB_Dependencies_Formatted;


-----------------------------------------------------------------------
-- Create a global temporary table to store dependencies across databases
CREATE TABLE ##db_dependencies 
(
id INTEGER IDENTITY(1,1) PRIMARY KEY,
-------------------------------------------------------------------------
-- Below are all the columns in the sys.sql_expression_dependencies table
referencing_id             INTEGER,
referencing_minor_id       INTEGER,
referencing_class          TINYINT,
referencing_class_desc     VARCHAR(60),
is_schema_bound_reference  BIT,
referenced_class           TINYINT,
referenced_class_desc      VARCHAR(60),
referenced_server_name     VARCHAR(128), --sysname,
referenced_database_name   VARCHAR(128), --sysname,
referenced_schema_name     VARCHAR(128), --sysname,
referenced_entity_name     VARCHAR(128), --sysname,
referenced_id              INTEGER,
referenced_minor_id        INTEGER,
is_caller_dependent        BIT,
is_ambiguous               BIT,
a                          CHAR(10) DEFAULT '>>>>>>>>>>',  --Creating a divider
-------------------------------------------------------------------------
--Below are created from the sys.objects, sys.schemas, etc. tables
referencing_database_name  VARCHAR(128),   --DB_NAME(vdatabase_id)
referencing_schema_name    VARCHAR(128),
referencing_type_desc      VARCHAR(60),
referencing_object_name    VARCHAR(128),
referenced_type_desc       VARCHAR(60),
referenced_schema_name2    VARCHAR(60),
b                          CHAR(10) DEFAULT '>>>>>>>>>>',--Creating a divider
-------------------------------------------------------------------------
--  Below are updated via UPDATE statements.
--  I will document what each of these columns represents. 
depth                      INTEGER,
inserttype                 TINYINT DEFAULT 0,
isUpdateDatabaseName       TINYINT DEFAULT 0,
isUpdateSchemaName         TINYINT DEFAULT 0,
isReferencedNotAnObject    TINYINT DEFAULT 0,
isReferencedValidObjectNotInObjects  TINYINT DEFAULT 0,
isCrossDatabaseReference   TINYINT DEFAULT 0,
isReferencingNoAnchor      TINYINT DEFAULT 0,
isSelfReferencingObject    TINYINT DEFAULT 0,
isObjectWithNoAnchor       TINYINT DEFAULT 0,
LoopIteration              INTEGER,
referencing_object         VARCHAR(1000),
referenced_object          VARCHAR(1000)
);


-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------

-- Part 1. Determine dependencies from `sys.sql_expression_dependency`.
-- Part 1. Determine dependencies from `sys.sql_expression_dependency`.
-- Part 1. Determine dependencies from `sys.sql_expression_dependency`.
-- Part 1. Determine dependencies from `sys.sql_expression_dependency`.

-- Populate #sql_statement table with the SQL statement pieces for dynamic execution
--INSERT INTO #sql_statement (rowid, sqlline)
SELECT id, rowid, sqlline
INTO   #sql_statement
FROM (VALUES
-----------------------------------------------
(1, 10, 'WITH cte_sql_expression_dependencies AS'),
(1, 20, '('),
(1, 30, 'SELECT *'),
(1, 40, 'FROM   vdatabase_name.sys.sql_expression_dependencies'),
(1, 50, 'WHERE  1=1'), 
-- Note the below predicate logic.
-- 
--(1, 60, 'AND referenced_minor_id = 0'),        --  Column ID when the referencing entity is a column; otherwise 0. Is not nullable.
--(1, 70, 'AND referencing_class = 1'),          --  Class of the referencing entity. 1 = Object or column
--(1, 80, 'AND referenced_class = 1'),           --  Class of the referenced entity. 1 = Object or column
--(1, 90, 'AND is_schema_bound_reference = 0'), 	--  1 = Referenced entity is schema-bound. 0 = Referenced entity is non-schema-bound.
--(1, 100, 'AND is_caller_dependent = 0'),        -- 0 = The referenced entity ID is not caller dependent.
(1, 110, ')'),
-----------------------------------------------
(1, 120,  'INSERT INTO ##db_dependencies ('),
(1, 130,  'referencing_id,'),
(1, 140,  'referencing_minor_id,'),
(1, 150, 'referencing_class,'),
(1, 160, 'referencing_class_desc,'),
(1, 170, 'is_schema_bound_reference,'),
(1, 180, 'referenced_class,'),
(1, 190, 'referenced_class_desc,'),
(1, 200, 'referenced_server_name,'),
(1, 210, 'referenced_database_name,'),
(1, 220, 'referenced_schema_name,'),
(1, 230, 'referenced_entity_name,'),
(1, 240, 'referenced_id,'),
(1, 250, 'referenced_minor_id,'),
(1, 260, 'is_caller_dependent,'),
(1, 270, 'is_ambiguous,'),
-----------------------------------------------
(1, 280, 'referencing_database_name,'),
(1, 290, 'referencing_schema_name,'),
(1, 300, 'referencing_type_desc,'),
(1, 310, 'referencing_object_name,'),
(1, 320, 'referenced_type_desc,'),
(1, 330, 'referenced_schema_name2,'),
(1, 340, 'InsertType'),
(1, 350, ')'),
-----------------------------------------------
(1, 360, 'SELECT'),
(1, 370, 'd.referencing_id,'),
(1, 380, 'd.referencing_minor_id,'),
(1, 390, 'd.referencing_class,'),
(1, 400, 'd.referencing_class_desc,'),
(1, 410, 'd.is_schema_bound_reference,'),
(1, 420, 'd.referenced_class,'),
(1, 430, 'd.referenced_class_desc,'),
(1, 440, 'd.referenced_server_name,'),
(1, 450, 'd.referenced_database_name,'),
(1, 460, 'd.referenced_schema_name,'),
(1, 470, 'd.referenced_entity_name,'),
(1, 480, 'd.referenced_id,'),
(1, 490, 'd.referenced_minor_id,'),
(1, 500, 'd.is_caller_dependent,'),
(1, 510, 'd.is_ambiguous,'),
-----------------------------------------------
(1, 520, 'DB_NAME(vdatabase_id) AS referencing_database_name,'),
(1, 530, 's.[name] AS referencing_schema_name,'),
(1, 550, 'o.type_desc AS referencing_type_desc,'),
(1, 560, 'o.name AS referencing_object_name,'),
(1, 570, 'r.type_desc AS referenced_type_desc,'),
(1, 580, 's2.name AS referenced_schema_name2,'),
(1, 590, 'CASE WHEN d.referencing_id IS NOT NULL THEN 1 ELSE 0 END AS inserttype'),
(1, 600, 'FROM'),
(1, 610, 'vdatabase_name.sys.objects o'),
(1, 620, 'LEFT OUTER JOIN cte_sql_expression_dependencies d ON o.object_id = d.referencing_id'),
(1, 630, 'LEFT OUTER JOIN vdatabase_name.sys.objects r ON d.referenced_id = r.object_id'),
(1, 640, 'INNER JOIN vdatabase_name.sys.schemas s ON o.schema_id = s.schema_id'),
(1, 650, 'LEFT OUTER JOIN vdatabase_name.sys.schemas s2 ON r.schema_id = s2.schema_id'),
(1, 660, 'WHERE'),
(1, 670, 'o.type_desc NOT IN (SELECT type_desc COLLATE SQL_Latin1_General_CP1_CI_AS FROM ##sysObjectsToIgnore)')

) AS a(id, RowID, SQLLine);


--SELECT * FROM ##db_dependencies;


/***********************************************************************************
--Use the following to view the above SQL statement!!!

SELECT  REPLACE(REPLACE(sqlline, 'vdatabase_name', 'bktb3_demo'),'vdatabase_id','') 
FROM    #sql_statement
WHERE   rowid >= (SELECT rowid FROM #sql_statement WHERE sqlline LIKE 'SELECT%');

***********************************************************************************/




DROP TABLE IF EXISTS ##databases;

SELECT ROW_NUMBER() OVER (ORDER BY [name]) AS RowID,
       database_id, 
       [name] AS [database_name]
INTO ##databases
FROM sys.databases
WHERE [name] NOT IN ('master','tempdb','model','msdb');


--References to sys.objects
DROP TABLE IF EXISTS ##sysobjectstoignore;

SELECT type_desc
INTO   ##sysObjectsToIgnore
--FROM     (VALUES ('test')) AS a(type_desc);
FROM   (VALUES ('INTERNAL_TABLE'),
              ('SERVICE_QUEUE'),
               ('SYSTEM_TABLE'),
--               ('DEFAULT_CONSTRAINT'),
               ('FOREIGN_KEY_CONSTRAINT'),
--               ('CHECK_CONSTRAINT'),
               ('PRIMARY_KEY_CONSTRAINT'),
               ('UNIQUE_CONSTRAINT'),
               ('dummy_test')
        ) AS a(type_desc);


---------------------------------------------
---------------------------------------------
-- Loop through targeted databases to gather object dependencies
DECLARE @vdatabase_id INTEGER;
DECLARE @vdatabase_name VARCHAR(8000);
DECLARE @vsqlstatement VARCHAR(8000);

DECLARE mycursor CURSOR FOR (SELECT database_id, database_name FROM ##databases);
OPEN mycursor;

FETCH NEXT FROM mycursor INTO @vdatabase_id, @vdatabase_name;
    WHILE @@FETCH_STATUS = 0
        BEGIN
        -- Construct dynamic SQL statement for dependency analysis
        SET @vsqlstatement = (SELECT STRING_AGG(sqlline,' ') FROM #sql_statement WHERE ID = 1);
        SET @vsqlstatement = REPLACE(@vsqlstatement,'vdatabase_name',@vdatabase_name);
        SET @vsqlstatement = REPLACE(@vsqlstatement,'vdatabase_id',@vdatabase_id);

        -- PRINT(@vSQLStatement);
        -- Execute the dynamic SQL
        EXEC (@vsqlstatement);
        FETCH NEXT FROM mycursor INTO @vdatabase_id, @vdatabase_name;
        END;
CLOSE mycursor;
DEALLOCATE mycursor;


-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-- Part 2.  Determine rules that need to be applied.
-- Part 2.  Determine rules that need to be applied.
-- Part 2.  Determine rules that need to be applied.
-- Part 2.  Determine rules that need to be applied.

-- Assume missing referenced database/schema names are 
-- the same as the referencing database/schema names.

-- The `sql_expression depenedencies` will have a NULL schema
-- name and NULL database name for depedencies in the same database.

-- For cross database dependencies, database name and 
-- schema name will be populated.

-- Some of these insert operations are crucial for determining depths, 
-- while others are utilized for analysis purposes.

-- 1
-- SET referenced_database_name = referencing_database_name
UPDATE  ##db_dependencies
SET     referenced_database_name = referencing_database_name,
        isupdatedatabasename = 1
WHERE   referenced_database_name IS NULL AND
        referenced_id IS NOT NULL AND
        inserttype = 1;
--PRINT(CONCAT('SET referenced_database_name = referencing_database_name: ', @@ROWCOUNT));


-- 2
-- SET isCrossDatabaseReference = 1
UPDATE  ##db_dependencies
SET     isCrossDatabaseReference = 1
WHERE   referenced_database_name <> referencing_database_name
--PRINT(CONCAT('SET isCrossDatabaseReference = 1: ', @@ROWCOUNT));


-- 3
-- SET referenced_schema_name = referenced_schema_name2
UPDATE  ##db_dependencies
SET     referenced_schema_name = referenced_schema_name2,
        isupdateschemaname = 1
WHERE   referenced_schema_name IS NULL AND
        referenced_id IS NOT NULL AND
        inserttype = 1;
--PRINT(CONCAT('SET referenced_schema_name = referenced_schema_name2: ', @@ROWCOUNT));


-- 4
-- SET isReferencedNotAnObject = 1
UPDATE  ##db_dependencies
SET     isReferencedNotAnObject = 1
WHERE   referenced_database_name IS NULL AND
        referenced_id IS NULL AND
        inserttype = 1;
--PRINT(CONCAT('SET isReferencedNotAnObject = 1: ', @@ROWCOUNT));


-- 5
-- SET isReferencedValidObjectNotInObjects = 1
-- These appear to be references to custom data types
UPDATE  ##db_dependencies
SET     isReferencedValidObjectNotInObjects = 1
WHERE   referenced_id IS NOT NULL AND
        referenced_type_desc IS NULL;
--PRINT(CONCAT('SET isReferencedValidObjectNotInObjects = 1: ', @@ROWCOUNT));


---------------------------------------------------
---------------------------------------------------
-- 6
-- SET Depth = 1 WHERE InsertType = 0
UPDATE  ##db_dependencies
SET     depth = 1
WHERE   InsertType = 0;
--PRINT(CONCAT('SET Depth = 1 WHERE InsertType = 0: ', @@ROWCOUNT));


---------------------------------------------------
-- 7
-- Set referenced_object = CONCAT
-- CONCAT will replace NULLs with an empty string
UPDATE ##db_dependencies
SET    referenced_object = CONCAT_WS('.', referenced_database_name, referenced_schema_name, referenced_entity_name)
--PRINT(CONCAT('Set referenced_object = CONCAT: ', @@ROWCOUNT));


-- 8
-- Set referencing_object = CONCAT
UPDATE ##db_dependencies
SET    referencing_object = CONCAT_WS('.', referencing_database_name, referencing_schema_name, referencing_object_name)
--PRINT(CONCAT('Set referencing_object = CONCAT: ', @@ROWCOUNT));


-- 9
-- Set referenced_object = NULL WHERE emptystring
UPDATE  ##db_dependencies
SET     referenced_object = NULL
WHERE   referenced_object = '';
--PRINT(CONCAT('Set referenced_object = NULL WHERE emptystring: ', @@ROWCOUNT));


-- 10
-- Set referencing_object = NULL where empty string
UPDATE  ##db_dependencies
SET     referencing_object = NULL
WHERE   referencing_object = '';
--PRINT(CONCAT('Set referencing_object = NULL where empty string: ', @@ROWCOUNT));


---------------------------------------------------
-- 11
--SET Depth = 1 for self referencing objectings
UPDATE  ##db_dependencies
SET     depth = 1,
        isSelfReferencingObject = 1
WHERE   referencing_object = referenced_object;
--PRINT(CONCAT('SET Depth = 1 for self referencing objectings: ', @@ROWCOUNT));


----------------------------------------------
----------------------------------------------
--  Part 3.  Determine object depth.
--  Part 3.  Determine object depth.
--  Part 3.  Determine object depth.
--  Part 3.  Determine object depth.

-- Recursively update the depth of dependencies.
-- This loop calculates the depth of each object within the dependency chain.
DECLARE @i INTEGER = 1;
DECLARE @rowcount INTEGER = 1;

WHILE @rowcount > 0
BEGIN

    WITH cte_Anchor AS
    (
    SELECT  DISTINCT
            referencing_object,
            depth
    FROM    ##db_dependencies
    WHERE   depth = @i AND referencing_object NOT IN (SELECT referencing_object FROM ##db_dependencies WHERE depth IS NULL)
    ),
    cte_ToUpdate AS
    (
    SELECT  referencing_object, referenced_object, depth
    FROM    ##db_dependencies
    WHERE   depth IS NULL AND InsertType = 1 AND referenced_object IS NOT NULL
    )
    UPDATE md
    SET    md.depth = md2.depth + 1
    FROM   cte_ToUpdate md INNER JOIN 
           cte_Anchor md2 ON md.referenced_object = md2.referencing_object;

    SET @rowcount = @@ROWCOUNT;
    SET @i = @i + 1;
    --PRINT(CONCAT(@i, ': Depth @@RowCount IS ',@rowcount));
END;


-- These are most probably stored procedures and functions who 
-- reference an invalid object. These should be investigated.
DROP TABLE IF EXISTS #ObjectsWithNoAnchor;

SELECT  DISTINCT referencing_object
INTO    #ObjectsWithNoAnchor
FROM    ##db_dependencies
WHERE   depth IS NULL AND
        referencing_object NOT IN (SELECT referencing_object
                                   FROM   ##db_dependencies
                                   WHERE  depth IS NOT NULL);


-- 12
--SET Depth = 1 for objects with no anchor
UPDATE ##db_dependencies
SET    Depth = 1,
       isObjectWithNoAnchor = 1
WHERE  referencing_object IN (SELECT referencing_object FROM #ObjectsWithNoAnchor);
--PRINT(CONCAT('SET Depth = 1 for objects with no anchor: ', @@ROWCOUNT));


--13
WITH cte_Distinct AS
(
SELECT  DISTINCT
        referencing_object,
        referencing_type_desc
FROM    ##db_dependencies
)
UPDATE  ##db_dependencies
SET     referenced_type_desc = b.referencing_type_desc
FROM    ##db_dependencies a INNER JOIN
        cte_Distinct b ON a.referenced_object = b.referencing_object
WHERE   referenced_type_desc IS NULL;
--PRINT(CONCAT('SET referenced_type_desc = referencing_type_desc for objects with no description: ', @@ROWCOUNT));


SELECT 'INSERT INTO sql_server_db_dependencies(application_name, hostname, depth, referencing_type_desc, referencing_object, referenced_type_desc, referenced_object) VALUES (' +
            CONCAT_WS(',',
                      QUOTENAME('DEFAULT_APP_NAME', ''''),
                --       QUOTENAME(@@SERVERNAME, ''''),
                      QUOTENAME('DEFAULT_SERVER_NAME', ''''),
                      CASE WHEN ISNULL(depth, '') = '' THEN 'NULL' ELSE QUOTENAME(ISNULL(depth, ''), '''') END,
                      QUOTENAME(ISNULL(referencing_type_desc, ''''), ''''),
                      QUOTENAME(ISNULL(referencing_object, ''''), ''''),
                      QUOTENAME(ISNULL(referenced_type_desc, ''''), ''''),
                      QUOTENAME(ISNULL(referenced_object, ''''), ''''))
            + ');' AS insert_statement
    FROM ##db_dependencies
    WHERE referenced_object NOT IN ('deleted', 'inserted');
